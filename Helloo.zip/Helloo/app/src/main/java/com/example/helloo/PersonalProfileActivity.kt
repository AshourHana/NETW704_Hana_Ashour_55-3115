package com.example.helloo

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class PersonalProfileActivity : AppCompatActivity() {

    private lateinit var tvUserEmail: TextView
    private lateinit var tvNote: TextView
    private lateinit var btnAddNote: Button
    private lateinit var btnSignOut: Button
    private lateinit var btnMap: Button

    // Shared Preferences to store the note locally
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_personal_profile)

        // Initialize views
        tvUserEmail = findViewById(R.id.tvUserEmail)
        tvNote = findViewById(R.id.tvNote)
        btnAddNote = findViewById(R.id.btnAddNote)
        btnSignOut = findViewById(R.id.btnSignOut)
        btnMap= findViewById(R.id.btnMap)

        // Initialize Shared Preferences
        sharedPreferences = getSharedPreferences("UserNote", Context.MODE_PRIVATE)

        // Display user's email
        val userEmail = FirebaseAuth.getInstance().currentUser?.email
        tvUserEmail.text = userEmail

        // Load and display the saved note (if any)
        val savedNote = sharedPreferences.getString("note", "No note added yet")
        tvNote.text = savedNote

        // Disable the button if a note is already saved
        if (savedNote != "No note added yet") {
            btnAddNote.isEnabled = false  // Disable the button after note is saved
        }

        // Set up the button to add a note
        btnAddNote.setOnClickListener {
            showNoteDialog()
        }

            // Sign out functionality
        btnSignOut.setOnClickListener {
            clearNote()
            FirebaseAuth.getInstance().signOut()
            finish()  // Redirect to LoginActivity or MainActivity
            }

        btnMap.setOnClickListener{
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)

        }
    }

    private fun showNoteDialog() {
        // Create an AlertDialog to add the note
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Add Note")

        // Set up an input field in the dialog
        val input = android.widget.EditText(this)
        builder.setView(input)

        // Set up the buttons
        builder.setPositiveButton("Save") { dialog, _ ->
            val newNote = input.text.toString()

            // Save the new note in Shared Preferences
            val editor = sharedPreferences.edit()
            editor.putString("note", newNote)
            editor.apply()

            // Update the TextView with the new note
            tvNote.text = newNote

            // Disable the button after saving the note
            btnAddNote.isEnabled = false

            dialog.dismiss()
        }

        builder.setNegativeButton("Cancel") { dialog, _ ->
            dialog.cancel()
        }

        builder.show()
    }
    private fun clearNote() {
        val editor = sharedPreferences.edit()
        editor.remove("note")  // Remove the note
        editor.apply()

        // Reset the note TextView and enable the button
        tvNote.text = "No note added yet"
        btnAddNote.isEnabled = true
    }
}
