package com.example.helloo

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainPage: AppCompatActivity() {
    private lateinit var btnMap: Button
    private lateinit var btnProfile: Button

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_page)

        btnMap = findViewById(R.id.btnMap)
        btnProfile= findViewById(R.id.btnProfile)

        btnMap.setOnClickListener{
            val intent= Intent(this,MapsActivity::class.java)
            startActivity(intent)
        }

        btnProfile.setOnClickListener{
            val intent1= Intent(this, PersonalProfileActivity::class.java)
            startActivity(intent1)
        }

    }
}